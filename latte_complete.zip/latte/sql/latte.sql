﻿DROP DATABASE IF EXISTS latte;
CREATE DATABASE latte DEFAULT CHARACTER SET utf8;

CREATE TABLE latte.category (
    category_id INT(8) AUTO_INCREMENT,
    name VARCHAR(128) NOT NULL,
    PRIMARY KEY(category_id)
);
CREATE TABLE latte.item (
    item_id INT(8) AUTO_INCREMENT,
    name VARCHAR(128) NOT NULL,
    maker VARCHAR(128) NOT NULL,
    price INT(8) NOT NULL,
    image VARCHAR(128) NOT NULL,
    category_id INT(8) NOT NULL,
    PRIMARY KEY(item_id)
);
CREATE TABLE latte.customer (
    customer_id INT(8) AUTO_INCREMENT ,
    name VARCHAR(128) NOT NULL,
    furigana VARCHAR(128) NOT NULL,
    zipcode CHAR(8) NOT NULL,
    address VARCHAR(256) NOT NULL,
    phone_number CHAR(20) NOT NULL,
    email VARCHAR(128) NOT NULL,
    PRIMARY KEY (customer_id)
);
CREATE TABLE latte.order_history (
    order_history_id INT(8) AUTO_INCREMENT,
    customer_id INT(8) NOT NULL,
    item_id INT(8) NOT NULL,
    PRIMARY KEY (order_history_id)
);

-- [category]
-- category_id INT(8) PRIMARY KEY AUTO_INCREMENT
-- name VARCHAR(128) NOT NULL
-- label VARCHAR(128) NOT NULL
INSERT INTO latte.category(name)
VALUES('書籍');
INSERT INTO latte.category(name)
VALUES('CD');
INSERT INTO latte.category(name)
VALUES('ゲーム');

-- [item]
-- item_id INT(8) PRIMARY KEY AUTO_INCREMENT
-- name VARCHAR(128) NOT NULL
-- maker VARCHAR(128) NOT NULL
-- price INT(8) NOT NULL
-- image VARCHAR(128) NOT NULL
-- category_id INT(8) NOT NULL
INSERT INTO latte.item(name,maker,price,image,category_id)
VALUES('ホリー・ポットー','ケン・ジャイシー',580,'img/h4.jpg',1);
INSERT INTO latte.item(name,maker,price,image,category_id)
VALUES('AGE of vase','ダンレッド',410,'img/h3.jpg',1);
INSERT INTO latte.item(name,maker,price,image,category_id)
VALUES('龍玉60年の歴史','島山明',600,'img/h2.jpg',1);
INSERT INTO latte.item(name,maker,price,image,category_id)
VALUES('メサニョキ','さくらむむこ',1050,'img/h1.jpg',1);
INSERT INTO latte.item(name,maker,price,image,category_id)
VALUES('Dream on and roll','AERO-Zeppelin',2945,'img/d1.jpg',2);
INSERT INTO latte.item(name,maker,price,image,category_id)
VALUES('song3','plur',2543,'img/l2.jpg',2);
INSERT INTO latte.item(name,maker,price,image,category_id)
VALUES('ウマトラ','浜崎あゆみ子',2800,'img/d3.jpg',2);
INSERT INTO latte.item(name,maker,price,image,category_id)
VALUES('In bar Dream','DATA WEST',7140,'img/g1.jpg',3);
INSERT INTO latte.item(name,maker,price,image,category_id)
VALUES('DANCE DANCE!!','小波',6090,'img/g2.jpg',3);
INSERT INTO latte.item(name,maker,price,image,category_id)
VALUES('COW GAME','忍転道',7329,'img/g4.jpg',3);
INSERT INTO latte.item(name,maker,price,image,category_id)
VALUES('IMPOSSIBLE IS NOTHING','南無子',4800,'img/g3.jpg',3);
INSERT INTO latte.item(name,maker,price,image,category_id)
VALUES('ひとりの野球','小波',4800,'img/no.png',3);

-- [customer]
-- customer_id INT(8) PRIMARY KEY AUTO_INCREMENT
-- name VARCHAR(128) NOT NULL
-- furigana VARCHAR(128) NOT NULL
-- zipcode CHAR(8) NOT NULL
-- address VARCHAR(256) NOT NULL
-- phone_number CHAR(20) NOT NULL
-- email VARCHAR(128) NOT NULL
INSERT INTO latte.customer(name,furigana,zipcode,address,phone_number,email)
VALUES ('山田太郎','ヤマダタロウ',
    '155-0031','東京都世田谷区北沢1-1-1KENコーポ203',
    '03-0000-0000','hogehoge@kenschool.jp');