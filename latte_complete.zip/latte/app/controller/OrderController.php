<?php
require_once ("app/controller/Controller.php");

class OrderController extends Controller
{

    /**
     * 注文ページへ遷移する
     *
     * @param array $params
     *            リクエストパラメータ
     * @param Model $model
     *            Modelオブジェクト
     * @return string Viewのパス
     */
    public function action($params, $model)
    {
        // $_SESSION["cart"]が空ではないか判定
        if (empty($_SESSION["cart"])) {
            throw new Exception("カートに商品がないため、注文ページへ遷移できませんでした。");
        } else {
            // カートにある商品を検索する処理
            $itemDao = createDao("ItemDao");
            // $model->cartItemsに検索結果を代入
            $cart = $itemDao->selectByItemIdList($_SESSION["cart"]);
            // 合計金額
            $total = 0;
            // カートにある商品の分だけ繰り返して金額を合計する
            foreach ($cart as $item) {
                $total += $item["price"];
            }
            $_SESSION["sumPrice"] = $total;
        }

        // メッセージをセット
        $model->message = "全項目が必須入力です。";

        // 注文ページのパスを返す
        return "app/view/order.php";
    }
}