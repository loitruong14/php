<?php
require_once ("app/controller/Controller.php");

class TopController extends Controller
{

    /**
     * トップページへ遷移する
     *
     * @param array $params
     *            リクエストパラメータ
     * @param Model $model
     *            Modelオブジェクト
     * @return string Viewのパス
     */
    public function action($params, $model)
    {
        // $_SESSION["category"]の初期化
        if (isset($_SESSION["category"]) === false) {
            $_SESSION["category"] = null;
        }

        // $_SESSION["keyword"]の初期化
        if (isset($_SESSION["keyword"]) === false) {
            $_SESSION["keyword"] = "";
        }

        // selectタグ内のoptionタグに指定する値を取得
        $categoryDao = createDao("CategoryDao");
        $model->categoryList = $categoryDao->selectAll();

        // トップページのパスを返す
        return "app/view/top.php";
    }
}