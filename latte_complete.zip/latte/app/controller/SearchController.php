<?php
require_once ("app/controller/Controller.php");

class SearchController extends Controller
{

    /**
     * 商品検索をするメソッド
     *
     * @param array $params
     *            リクエストパラメータ
     * @param Model $model
     *            Modelオブジェクト
     * @return string Viewのパス
     */
    public function action($params, $model)
    {
        // 検索処理
        $itemDao = createDao("ItemDao");
        // $_SESSION["searchResults"]に検索結果を代入
        $_SESSION["searchResults"] = $itemDao->selectByCategoryAndKeyword($params->category, $params->keyword);

        // $_SESSION["category"]にリクエストパラメータの"category"を代入
        $_SESSION["category"] = $params->category;

        // $_SESSION["keyword"]にリクエストパラメータの"keyword"を代入
        $_SESSION["keyword"] = $params->keyword;

        // selectタグ内のoptionタグに指定する値を取得
        $categoryDao = createDao("CategoryDao");
        $model->categoryList = $categoryDao->selectAll();

        // トップページのパスを返す
        return "app/view/top.php";
    }
}