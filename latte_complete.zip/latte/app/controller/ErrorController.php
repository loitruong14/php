<?php
require_once ("app/controller/Controller.php");

class ErrorController extends Controller
{

    /**
     * エラーページへ遷移する
     *
     * @param array $params
     *            リクエストパラメータ
     * @param Model $model
     *            Modelオブジェクト
     * @return string Viewのパス
     */
    public function action($params, $model)
    {
        // エラーページのパスを返す
        return "app/view/error.php";
    }
}