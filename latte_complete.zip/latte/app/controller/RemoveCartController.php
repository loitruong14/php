<?php
require_once ("app/controller/Controller.php");

class RemoveCartController extends Controller
{

    /**
     * ショッピングカートから商品を削除する
     *
     * @param array $params
     *            リクエストパラメータ
     * @param Model $model
     *            Modelオブジェクト
     * @return string Viewのパス
     */
    public function action($params, $model)
    {
        // $_SESSION["cart"]が空ではないか判定
        if (empty($_SESSION["cart"])) {
            throw new Exception("カートから商品を削除できませんでした。");
        }

        // 配列から指定したインデックスの要素を削除する
        // （補足）連想配列の場合はunset()関数を使用する
        array_splice($_SESSION["cart"], $params->index, 1);

        // 検索処理
        $itemDao = createDao("ItemDao");
        // $model->cartItemsに検索結果を代入
        $model->cartItems = $itemDao->selectByItemIdList($_SESSION["cart"]);

        // カートページのパスを返す
        return "app/view/cart.php";
    }
}