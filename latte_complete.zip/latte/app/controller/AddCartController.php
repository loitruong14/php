<?php
require_once ("app/controller/Controller.php");

class AddCartController extends Controller
{

    /**
     * ショッピングカートへ商品を追加する
     *
     * @param array $params
     *            リクエストパラメータ
     * @param Model $model
     *            Modelオブジェクト
     * @return string Viewのパス
     */
    public function action($params, $model)
    {
        // $params->itemIdが空ではないか判定
        if (empty($params->itemId)) {
            throw new Exception("カートに商品を追加できませんでした。");
        }

        // $_SESSION["cart"]の初期化（配列生成して代入）
        if (isset($_SESSION["cart"]) === false) {
            $_SESSION["cart"] = array();
        }

        // 配列の要素に、リクエストパラメータのitemIdを代入
        $_SESSION["cart"][] = $params->itemId;

        // selectタグ内のoptionタグに指定する値を取得
        $categoryDao = createDao("CategoryDao");
        $model->categoryList = $categoryDao->selectAll();

        // トップページのパスを返す
        return "app/view/top.php";
    }
}