<?php
require_once ("app/controller/Controller.php");

class OrderCompleteController extends Controller
{

    /**
     * 注文完了ページへ遷移する
     *
     * @param array $params
     *            リクエストパラメータ
     * @param Model $model
     *            Modelオブジェクト
     * @return string Viewのパス
     */
    public function action($params, $model)
    {
        // 未入力の項目がある場合の処理
        if (! $this->inputCheck($params)) {
            // リクエストパラメータを$model（Modelオブジェクト)にセット
            $model->setProperties($params->getProperties());

            // エラーメッセージをセット
            $model->message = "未入力項目があります。ご確認ください。";

            // 注文ページのパスを返す
            return "app/view/order.php";
        }

        // 顧客情報の登録処理
        $customerDao = createDao("CustomerDao");
        // 配列[名前, フリガナ, 郵便番号, 住所, 電話番号, Eメール]
        $values = array(
            $params->name,
            $params->furigana,
            $params->zipcode,
            $params->address,
            $params->phoneNumber,
            $params->email
        );
        $newCustomerId = $customerDao->insert($values);

        // 購入商品の登録処理
        $orderHistoryDao = createDao("OrderHistoryDao");
        $multiValues = array();
        foreach ($_SESSION["cart"] as $itemId) {
            // 配列[顧客ID, 商品ID]
            $multiValues[] = array(
                $newCustomerId,
                $itemId
            );
        }
        $orderHistoryDao->insert($multiValues);

        // セッションを破棄する
        session_invalidate();
        // 注文完了ページのパスを返す
        return "app/view/order_complete.php";
    }

    /**
     * リクエストパラメータの入力チェックをする
     *
     * @param array $params
     *            リクエストパラメータ
     * @return boolean true（未入力なし）または、false（未入力あり）
     */
    private function inputCheck($params)
    {
        // 名前の入力チェック
        if (empty($params->name)) {
            return false;
        }
        // フリガナの入力チェック
        if (empty($params->furigana)) {
            return false;
        }
        // 郵便番号の入力チェック
        if (empty($params->zipcode)) {
            return false;
        }
        // 住所の入力チェック
        if (empty($params->address)) {
            return false;
        }
        // 電話番号の入力チェック
        if (empty($params->phoneNumber)) {
            return false;
        }
        // メールアドレスの入力チェック
        if (empty($params->email)) {
            return false;
        }
        return true;
    }
}