<?php
require_once ("app/controller/Controller.php");

class CartController extends Controller
{

    /**
     * カートページへ遷移する
     *
     * @param array $params
     *            リクエストパラメータ
     * @param Model $model
     *            Modelオブジェクト
     * @return string Viewのパス
     */
    public function action($params, $model)
    {
        if (isset($_SESSION["cart"])) {
            // カートにある商品を検索する処理
            $itemDao = createDao("ItemDao");
            // $model->cartItemsに検索結果を代入
            $model->cartItems = $itemDao->selectByItemIdList($_SESSION["cart"]);
        }

        // カートページのパスを返す
        return "app/view/cart.php";
    }
}