<?php

/**
 * htmlspecialchars()の簡易化関数
 * @param string $string
 *     XSS対策処理を行う文字列
 * @return string
 *     XSS対策処理後の文字列
 */
function h($string)
{
    return htmlspecialchars($string, ENT_QUOTES);
}

/**
 * セッションを破棄する関数
 *
 * @return void
 */
function session_invalidate()
{
    // セッションが開始していない場合はセッションを開始する
    if (session_id() === "") {
        session_start();
    }
    // セッション変数を全て解除する
    $_SESSION = array();
    // セッションクッキーを削除する
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), "", time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
    }
    // 最後に、セッションに登録されたデータを全て破棄する
    session_destroy();
}

/**
 * ログをとる関数
 *
 * @return void
 */
function app_log($message)
{
    $path = 'logs/app.log';
    // 日時の取得
    $datetime = date('Y-m-d H:i:s');
    error_log('[' . $datetime . '] ' . $message . PHP_EOL, 3, $path);
}

/**
 * コントローラーオブジェクトを生成する関数
 *
 * @param string $className
 *            コントローラークラス名
 * @return Controller オブジェクト
 */
function createController($className)
{
    // 指定されたクラス（ファイル）を読み込み
    $classPath = "app/controller/" . $className . ".php";
    require_once ($classPath);
    // クラスからオブジェクト生成して返す
    return new $className();
}

/**
 * DAOオブジェクトを生成する関数
 *
 * @param string $className
 *            DAOクラス名
 * @return DAO オブジェクト
 */
function createDao($className)
{
    $classPath = "app/dao/" . $className . ".php";
    require_once ($classPath);
    // クラスからオブジェクト生成して返す
    return new $className();
}