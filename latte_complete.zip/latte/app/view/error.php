<?php header("Content-Type:text/html;charset=utf-8"); ?>
<?php $title = "エラーページ" ?>
<?php require_once ("header.php"); ?>
	<div id="content">
		<h3>エラーページ</h3>
		<p class="error_message">
			エラーが発生しました。<br>
			<?php echo $model->message; ?>
		</p>
		<p class="pageback">
			<a href="index.php">検索ページに戻る</a>
		</p>
	</div>
<?php require_once ("footer.php"); ?>
