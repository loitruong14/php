<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="css/style.css">
<title>ショッピングサイトLatte｜<?php echo $title; ?></title>
</head>
<body>
	<div id="wrap">
		<div id="header">
			<h1>
				<a href="index.php"> <img src="img/logo.gif" alt="ショッピングサイトLatte" width="137" height="13"> </a>
			</h1>
			<ul class="navi_list">
				<li class="h_home"><a href="#">HOME</a></li>
				<li class="h_guide"><a href="#">ショップガイド</a></li>
				<li class="h_que"><a href="#">よくある質問</a></li>
				<li class="h_com"><a href="#">会社案内</a></li>
				<li class="h_con"><a href="#">お問い合わせ</a></li>
			</ul>
			<h2>Latte <?php echo $title; ?></h2>
		</div>
		<div id="content_wrap">
			<div id="menu">
				<ul class="guide_list">
					<li><a href="#">ご購入方法</a></li>
					<li><a href="#">お支払方法</a></li>
					<li><a href="#">配送料</a></li>
					<li><a href="#">ラッピング</a></li>
					<li><a href="#">返品・交換</a></li>
				</ul>
				<p class="cart_button">
					<a href="index.php?action=cart"> <img src="img/btn_cart.gif" width="146" height="20"> </a>
				</p>
				<p class="notification">
					全国無料配送！<br> クレジットカードも<br> ご利用になれます。
				</p>
				<address class="com_info">
					販売元<br> (株)シンクスバンク
				</address>
			</div>
