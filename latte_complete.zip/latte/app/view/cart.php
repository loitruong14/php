<?php header("Content-Type:text/html;charset=utf-8"); ?>
<?php $title = "カートページ" ?>
<?php require_once ("header.php"); ?>
	<div id="content">
		<h3>カート内の商品</h3>
		<?php if(empty($model->cartItems)): ?>
			<p class="cart_message">カートに商品はありません。</p>
		<?php else: ?>
			<p class="cart_message">現在買い物カゴには以下の商品が入っています。</p>
			<table class="cart_items">
				<tr>
					<th>商品名</th>
					<th>メーカーなど</th>
					<th>価格</th>
					<th>&nbsp;</th>
				</tr>
				<?php $index = 0; //配列のインデックス?>
				<?php foreach($model->cartItems as $item): ?>
    				<tr>
						<td><?php echo $item["name"]; ?></td>
						<td><?php echo $item["maker"]; ?></td>
						<td><?php echo $item["price"]; ?>円</td>
						<td>
							<form action="index.php" method="post">
								<input type="submit" value="取り消し">
								<input type="hidden" name="action" value="removeCart">
								<input type="hidden" name="index" value="<?php echo $index; ?>">
							</form>
						</td>
    				</tr>
					<?php $index++; //$indexをインクリメント ?>
				<?php endforeach; ?>
			</table>
			<p class="order_button">
				<a href="index.php?action=order"> <img src="img/btn_confirmation.gif" width="150" height="20"> </a>
			</p>
		<?php endif; ?>
		<p class="pageback">
			<a href="index.php">検索ページに戻る</a>
		</p>
	</div>
<?php require_once ("footer.php"); ?>
