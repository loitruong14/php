<?php header("Content-Type:text/html;charset=utf-8"); ?>
<?php $title = "トップページ" ?>
<?php require_once ("header.php"); ?>
	<div id="main_visual">
		<img src="img/main_img.jpg" width="526" height="107">
	</div>
	<div id="serchbox">
		<h3>カテゴリーを選択して検索して下さい。</h3>
		<form action="index.php" method="post">
			<table class="search">
				<tr>
					<th>分類</th>
					<td><select name="category">
						<?php foreach($model->categoryList as $category): ?>
							<?php if($category["category_id"] === $_SESSION["category"]): ?>
								<option value="<?php echo $category["category_id"]; ?>" selected><?php echo $category["name"]; ?></option>
							<?php else: ?>
								<option value="<?php echo $category["category_id"]; ?>"><?php echo $category["name"]; ?></option>
							<?php endif; ?>
						<?php endforeach;?>
					</select></td>
					<th>キーワード</th>
					<td><input type="text" name="keyword" size="20" value="<?php echo h($_SESSION["keyword"]); ?>"></td>
					<td><input type="submit" value="検索"> <input type="hidden" name="action" value="search"></td>
				</tr>
			</table>
		</form>
	</div>
	<div id="content">
		<div id="select_item">
			<h3>現在選択されている商品</h3>
			<p class="item_count">
				選択商品　<?php echo (isset($_SESSION["cart"])) ? count($_SESSION["cart"]) : 0; ?>　個
			</p>
			<p class="cart_btn">
				<a href="index.php?action=cart">
					<img src="img/btn_cart.gif" width="146" height="20">
				</a>
			</p>
		</div>
		<div id="select_category">
			<h3>選択カテゴリー商品</h3>
			<?php if(isset($_SESSION["searchResults"])): ?>
				<?php if(empty($_SESSION["searchResults"])): ?>
					<p class="search_message">該当する商品はありません。</p>
				<?php else: ?>
					<table class="search_items">
						<tr>
							<th>商品</th>
							<th>商品名</th>
							<th>メーカーなど</th>
							<th>価格</th>
							<th>&nbsp;</th>
						</tr>
						<?php foreach($_SESSION["searchResults"] as $result): ?>
							<tr>
								<td><img src="<?php echo $result["image"]; ?>" alt="<?php echo $result["name"]; ?>"></td>
								<td><?php echo $result["name"]; ?></td>
								<td><?php echo $result["maker"]; ?></td>
								<td><?php echo $result["price"]; ?>円</td>
								<td>
								<form action="index.php" method="post">
									<input type="image" src="img/btn_addition.gif">
									<input type="hidden" name="action" value="addCart">
									<input type="hidden" name="itemId" value="<?php echo $result["item_id"]; ?>">
								</form>
								</td>
							</tr>
						<?php endforeach; ?>
					</table>
				<?php endif; ?>
			<?php else: ?>
				<p class="search_message">商品を検索してください。</p>
			<?php endif; ?>
		</div>
	</div>
<?php require_once ("footer.php"); ?>
