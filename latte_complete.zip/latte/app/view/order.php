<?php header("Content-Type:text/html;charset=utf-8"); ?>
<?php $title = "注文ページ" ?>
<?php require_once ("header.php"); ?>
	<div id="content">
		<h3>合計金額</h3>
		<p class="total">
			現在買い物カゴの合計金額は <span><?php echo $_SESSION["sumPrice"]; ?>円（税込み）</span>	です。
		</p>
		<h3>注文者情報</h3>
		<p class="order_message"><?php echo $model->message; ?></p>
		<form action="index.php" method="post">
			<table class="customer">
				<tr>
					<th>お名前</th>
					<td><input type="text" name="name" size="50"
						value="<?php echo h($model->name); ?>"><br> （例）山田 太郎</td>
				</tr>
				<tr>
					<th>フリガナ</th>
					<td><input type="text" name="furigana" size="50"
						value="<?php echo h($model->furigana); ?>"><br> （例）ヤマダ タロウ</td>
				</tr>
				<tr>
					<th>郵便番号</th>
					<td><input type="text" name="zipcode" size="8"
						value="<?php echo h($model->zipcode); ?>"><br> （例）153-0052<br>
						※郵便番号検索は<a class="zipcode"
						href="https://www.post.japanpost.jp/zipcode/index.html"
						target="_blank">こちら</a></td>
				</tr>
				<tr>
					<th>住所</th>
					<td><input type="text" name="address" size="60"
						value="<?php echo h($model->address); ?>"><br> （例）東京都目黒区目黒2-2-2
						○○ビル30F 総務部<br> ※ マンション・アパート名は必ず入力してください。<br> ※
						住所が勤務先の場合は「部署名」なども入力してください。</td>
				</tr>
				<tr>
					<th>電話番号</th>
					<td><input type="text" name="phoneNumber" size="20"
						value="<?php echo h($model->phoneNumber); ?>"><br>
						（例）03-0000-0000</td>
				</tr>
				<tr>
					<th>メールアドレス</th>
					<td><input type="text" name="email" size="50"
						value="<?php echo h($model->email); ?>"><br>
						（例）hogehoge@kenschool.jp</td>
				</tr>
			</table>
			<p class="order_message">上記の内容で問題なければ、注文を確定します。</p>
			<p class="order_button">
				<input name="cart_enter" type="image" src="img/btn_order.gif">
				<input type="hidden" name="action" value="orderComplete">
			</p>
		</form>
		<p class="pageback">
			<a href="index.php?action=cart">ショッピングカートに戻る</a>
			<a href="index.php">検索ページに戻る</a>
		</p>
	</div>
<?php require_once ("footer.php"); ?>
