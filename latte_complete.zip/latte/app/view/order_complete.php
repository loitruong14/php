<?php header("Content-Type:text/html;charset=utf-8"); ?>
<?php $title = "注文完了ページ" ?>
<?php require_once ("header.php"); ?>
	<div id="content">
		<h3>注文完了</h3>
		<p class="complete_message">
			ご注文ありがとうございます。<br>
			24時間以内に当サイト管理者よりメールがまいりますので、よろしくお願い致します。<br>
			在庫状況により商品の到着が遅れる場合がございますので、あらかじめご了承ください。
		</p>
		<p class="pageback">
			<a href="index.php">検索ページに戻る</a>
		</p>
	</div>
<?php require_once ("footer.php"); ?>
