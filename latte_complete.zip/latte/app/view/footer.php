			<p class="pageup">
				<a href="#top"> <img src="img/page_top.gif" width="49" height="9"> </a>
			</p>
		</div>
		<div id="footer">
			<small>&copy;Copyright 2012 ThinkethBank,Inc. All rights reserved.</small>
		</div>
	</div>
</body>
</html>