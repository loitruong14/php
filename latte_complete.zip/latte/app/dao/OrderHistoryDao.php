<?php
require_once ("app/dao/Dao.php");

class OrderHistoryDao extends Dao
{

    /**
     * order_history表に登録するメソッド
     *
     * @param array $multiValues
     *            二次元配列(顧客ID, 商品ID)
     * @return integer 最後に挿入された行ID
     */
    public function insert($multiValues)
    {
        $insertIdList = array();
        try {
            // データベースへ接続
            $this->open();
            // トランザクション開始
            $this->beginTransaction();
            // 全件検索
            $sql = "INSERT INTO order_history(customer_id,item_id) VALUES(?,?)";
            $statement = $this->prepare($sql);
            foreach ($multiValues as $values) {
                $statement->execute($values);
                $insertIdList[] = $this->lastInsertId();
            }
            // コミット
            $this->commit();
        } catch (PDOException $e) {
            // ロールバック
            $this->rollback();
            $message = "データベースエラー:" . basename($e->getFile()) . "(" . $e->getLine() . ")";
            throw new Exception($message);
        } finally{
            // PDOStatementオブジェクトの解放
            $statement = null;
            // データベースから切断
            $this->close();
        }
        return $insertIdList;
    }
}