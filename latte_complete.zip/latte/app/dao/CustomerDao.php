<?php
require_once ("app/dao/Dao.php");

class CustomerDao extends Dao
{

    /**
     * customer表に登録するメソッド
     *
     * @param array $values
     *            配列(名前, フリガナ, 郵便番号, 住所, 電話番号, Eメール)
     * @return integer 最後に挿入された行ID
     */
    public function insert($values)
    {
        $insertId = null;
        try {
            // データベースへ接続
            $this->open();
            // データ登録
            $sql = "INSERT INTO customer(name,furigana,zipcode,address,phone_number,email) VALUES(?,?,?,?,?,?)";
            $statement = $this->prepare($sql);
            $statement->execute($values);
            $insertId = $this->lastInsertId();
        } catch (PDOException $e) {
            $message = "データベースエラー:" . basename($e->getFile()) . "(" . $e->getLine() . ")";
            throw new Exception($message);
        } finally{
            // PDOStatementオブジェクトの解放
            $statement = null;
            // データベースから切断
            $this->close();
        }
        return $insertId;
    }
}