<?php
require_once ("app/dao/Dao.php");

class CategoryDao extends Dao
{

    /**
     * category表から全件検索するメソッド
     *
     * @return array 検索結果（二次元配列）
     */
    public function selectAll()
    {
        $rows = array();
        try {
            // データベースへ接続
            $this->open();
            // 全件検索
            $sql = "SELECT * FROM category ORDER BY category_id ";
            $statement = $this->prepare($sql);
            $statement->execute();
            $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $message = "データベースエラー:" . basename($e->getFile()) . "(" . $e->getLine() . ")";
            throw new Exception($message);
        } finally{
            // PDOStatementオブジェクトの解放
            $statement = null;
            // データベースから切断
            $this->close();
        }
        return $rows;
    }
}