<?php
require_once ("app/dao/Dao.php");

class ItemDao extends Dao
{

    /**
     * item表から、カテゴリーIDとキーワードをもとに検索するメソッド
     *
     * @param integer $category
     *            カテゴリーID
     * @param string $keyword
     *            キーワード
     * @return array 検索結果（二次元配列）
     */
    public function selectByCategoryAndKeyword($category, $keyword)
    {
        $rows = array();
        try {
            // データベースへ接続
            $this->open();
            // SQLの選択
            $sql = "SELECT * FROM item";
            if (empty($keyword)) {
                $sql .= " WHERE category_id=? ORDER BY item_id ";
                $params = array(
                    $category
                );
            } else {
                $sql .= " WHERE category_id=? AND (name LIKE ? OR maker LIKE ?) ORDER BY item_id ";
                $keyword = "%" . $keyword . "%";
                $params = array(
                    $category,
                    $keyword,
                    $keyword
                );
            }
            // カテゴリーID、またはカテゴリーIDとキーワードをもとに検索
            $statement = $this->prepare($sql);
            $statement->execute($params);
            $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $message = "データベースエラー:" . basename($e->getFile()) . "(" . $e->getLine() . ")";
            throw new Exception($message);
        } finally{
            // PDOStatementオブジェクトの解放
            $statement = null;
            // データベースから切断
            $this->close();
        }
        return $rows;
    }

    /**
     * item表から商品IDリストをもとに検索するメソッド
     *
     * @param array $itemIdList
     *            商品IDリスト
     * @return array 検索結果（二次元配列）
     */
    public function selectByItemIdList($itemIdList)
    {
        $rows = array();
        try {
            // データベースへ接続
            $this->open();
            // SQLの設定
            if (empty($itemIdList) === false) {
                $sql = "SELECT * FROM item WHERE item_id = ?";
                $statement = $this->prepare($sql);

                // $itemIdListの要素数の分だけ繰り返す
                foreach ($itemIdList as $itemId) {
                    // 商品IDのリストをもとに検索
                    $statement->execute(array($itemId));
                    $rows[] = $statement->fetch(PDO::FETCH_ASSOC);
                }
            }
        } catch (PDOException $e) {
            $message = "データベースエラー:" . basename($e->getFile()) . "(" . $e->getLine() . ")";
            throw new Exception($message);
        } finally{
            // PDOStatementオブジェクトの解放
            $statement = null;
            // データベースから切断
            $this->close();
        }
        return $rows;
    }
}